<!-- FOOTER -->
<footer id="contact" class="mt-5">
  <div class="container-flui p-5 ">
    <?php echo '<p class="t-center">Exo_blog - PHP</p>'; ?>
    <p>&copy; Colombbus - Paris 2022</p>
    
  </div>
</footer>
<!-- FIN FOOTER -->

    <!-- Bootstrap JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  